package com.apiGeneralV8.APIv8Baterias;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApIv8BateriasApplicationTests {

	@Test
	void contextLoads() {
	}

}
