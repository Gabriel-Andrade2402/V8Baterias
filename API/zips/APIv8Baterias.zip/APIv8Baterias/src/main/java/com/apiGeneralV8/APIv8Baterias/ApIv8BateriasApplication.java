package com.apiGeneralV8.APIv8Baterias;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApIv8BateriasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApIv8BateriasApplication.class, args);
	}

}
